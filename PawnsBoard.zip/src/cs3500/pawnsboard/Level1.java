package cs3500.pawnsboard;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;

import cs3500.pawnsboard.controller.DeckReader;
import cs3500.pawnsboard.model.Board;
import cs3500.pawnsboard.model.NewBoard;
import cs3500.pawnsboard.model.PawnsBoardCard;
import cs3500.pawnsboard.model.PawnsBoardInterface;
import cs3500.pawnsboard.model.Player;
import cs3500.pawnsboard.view.NewTextualView;
import cs3500.pawnsboard.view.PawnsBoardView;

/**
 * Class to implement Level1 with a few steps.
 */
public class Level1 {
  /**
   * The main method for demonstrating the implementation of
   * new influence types and the updated textual view.
   * @param args command-line arguments
   * @throws IOException if an error occurs while reading the deck configuration file
   */
  public static void main(String[] args) throws IOException {
    String pathRed = "docs" + File.separator + "newDeck.config";
    String pathBlue = "docs" + File.separator + "newDeck.config";
    List<PawnsBoardCard> redDeck = DeckReader.readDeck(pathRed, Player.Red);
    List<PawnsBoardCard> blueDeck = DeckReader.readDeck(pathBlue, Player.Blue);

    PawnsBoardInterface board = new NewBoard(new Board(5, 7, new Random()));
    board.startGame(redDeck, blueDeck, false,5);
    PawnsBoardView view = new NewTextualView(board);

    System.out.println(view);
    System.out.println();

    System.out.println("<Red>------------Placed B at [2, 1]-----------");
    board.drawCard();
    board.placeCard(2,1,0);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Blue>-----------Placed A at [3, 7]-----------");
    board.placeCard(0,2,6);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Red>------------Placed B at [3, 1]-----------");
    board.placeCard(2, 2,0);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Blue>------------Placed C at [3, 6]-----------");
    board.placeCard(3, 2,5);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Red>------------Placed A at [2, 3]-----------");
    board.placeCard(0, 1,2);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Blue>-----------Placed B at [2, 7]-----------");
    board.placeCard(1, 1, 6);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Red>----------------Pass Turn----------------");
    board.passTurn();
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Blue>-----------Placed D at [2, 5]-----------");
    board.placeCard(4, 1, 4);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Red>------------Placed D at [1, 3]-----------");
    board.placeCard(0, 0,2);
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Blue>---------------Pass Turn----------------");
    board.passTurn();
    board.drawCard();
    System.out.println(view);
    System.out.println();

    System.out.println("<Red>------------Placed F at [1, 4]-----------");
    board.placeCard(6, 0,3);
    board.drawCard();
    System.out.println(view);
  }
}